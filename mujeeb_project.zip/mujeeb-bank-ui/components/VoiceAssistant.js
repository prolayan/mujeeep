
import React, { useState } from 'react';
import { sendToMujeeb } from '../api/mujeebApi';

const VoiceAssistant = () => {
  const [userText, setUserText] = useState('');
  const [mujeebReply, setMujeebReply] = useState('');
  const [listening, setListening] = useState(false);

  const startListening = () => {
    const recognition = new window.webkitSpeechRecognition();
    recognition.lang = 'ar-SA';
    recognition.interimResults = false;

    recognition.onstart = () => setListening(true);
    recognition.onend = () => setListening(false);

    recognition.onresult = async (event) => {
      const transcript = event.results[0][0].transcript;
      setUserText(transcript);

      const reply = await sendToMujeeb(transcript);
      setMujeebReply(reply);
      speak(reply);
    };

    recognition.onerror = (event) => {
      console.error('🟥 خطأ الصوت:', event.error);
    };

    recognition.start();
  };

  const speak = (text) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ar-SA';
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div>
      <button onClick={startListening} disabled={listening}>
        {listening ? '📡 يستمع...' : '🎤 اسأل مجيب'}
      </button>

      <div>
        <p><strong>أنت:</strong> {userText}</p>
        <p><strong>مجيب:</strong> {mujeebReply}</p>
      </div>
    </div>
  );
};

export default VoiceAssistant;
