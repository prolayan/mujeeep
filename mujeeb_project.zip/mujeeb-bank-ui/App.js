
import React from 'react';
import VoiceAssistant from './components/VoiceAssistant';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>مرحبا بك في بنك مجيب</h1>
      <VoiceAssistant />
    </div>
  );
}

export default App;
